<template>
<div class="p-4 bg-white border border-gray-200 rounded-lg">
        <h3 class="mb-6 text-xl">Trends</h3>

        <div class="space-y-4">
            <div class="flex items-center justify-between">
                <p class="text-xs">
                    <strong>#codewithstein</strong><br>
                    <span class="text-gray-500">180 posts</span>
                </p>

                <a href="#" class="py-2 px-3 bg-purple-600 text-white text-xs rounded-lg">Explore</a>
            </div>

            <div class="flex items-center justify-between">
                <p class="text-xs">
                    <strong>#codewithstein</strong><br>
                    <span class="text-gray-500">180 posts</span>
                </p>

                <a href="#" class="py-2 px-3 bg-purple-600 text-white text-xs rounded-lg">Explore</a>
            </div>

            <div class="flex items-center justify-between">
                <p class="text-xs">
                    <strong>#codewithstein</strong><br>
                    <span class="text-gray-500">180 posts</span>
                </p>

                <a href="#" class="py-2 px-3 bg-purple-600 text-white text-xs rounded-lg">Explore</a>
            </div>

            <div class="flex items-center justify-between">
                <p class="text-xs">
                    <strong>#codewithstein</strong><br>
                    <span class="text-gray-500">180 posts</span>
                </p>

                <a href="#" class="py-2 px-3 bg-purple-600 text-white text-xs rounded-lg">Explore</a>
            </div>
        </div>
    </div>
</template>